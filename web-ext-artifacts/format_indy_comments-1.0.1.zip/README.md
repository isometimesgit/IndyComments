# Media Extractor

Extract url from browser request with media file extension(s) to clipboard.

Typical case would be to visit a website with embedded video player then pressing play to extract the underlying video url to the clipboard. The extracted url can then be used in a stand alone video player.

NOTE: is currently not working with youtube.